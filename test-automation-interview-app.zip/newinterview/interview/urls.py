from django.urls import path

from interview import views

urlpatterns = [
    path('', views.index, name="index"),
    path('register/', views.register, name='register'),
    path('home/', views.landing, name='home'),
    path('logout/', views.logout, name='logout'),
    path('java/', views.java_questions, name='java'),
    path('add/question/', views.add_question, name='add_question'),
    path('questions/', views.questions, name='questions'),
    path('update/question/<int:question_id>', views.question, name='question'),
    path('delete/question/<int:question_id>', views.delete_question, name='delete_question'),
    path('delete/answer/<int:answer_id>/<int:question_id>',views.delete_answer, name='delete_answer'),




]
