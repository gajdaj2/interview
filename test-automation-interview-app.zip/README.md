### Pre-requsits before start using Mobile Bank:  

1. Install Python 3.9  Remember to add python to PATH system variable during installation 
2. Execute command and check installation: 

   a. `python --version` 
   b. `pip --version`

# Installation process 

### 2. Execute command:
       git clone ssh://git@bitbucket.itgit.oneadr.net:7999/gta/test-automation-interview-app.git
### 3. Go to folder \newinterview and execute command: 
   ``` pip install --index-url https://artifactory.itcm.oneadr.net/api/pypi/pypi-remote/simple/ -r requirements.txt ```
   This will install all dependecies please remember that file requirements.txt is in mDoctor folder
### 4. Execute command: 
   ``` python manage.py runserver ```
   
### You will see :
    Watching for file changes with StatReloader
    Performing system checks...


   
### Open link http://127.0.0.1:8000 You will see welcome page
    If you want use existing user login: kuba password: 123456
    You can create your own user :)
    ![alt text](./welcome.png)

### Have fun  